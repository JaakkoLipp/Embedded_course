/*
 * Exercise 3_LCD_Keypad.c
 *
 * Created: 1/12/2025 11:47:41 AM
 * Author : Anafi Nur'aini
 */ 

#define F_CPU 16000000UL
#define BAUD 9600


#include <avr/io.h>
#include "keypad.h"
#include "lcd.h" // lcd header file made by Peter Fleury
#include <util/delay.h>
#include <util/setbaud.h>
#include <stdio.h>
#include <stdlib.h>

// Initialize LCD and Keypad
void setup() {
	// Initialize LCD
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	lcd_puts("Ready");
	_delay_ms(1000); // Delay to display initial message

	// Initialize Keypad
	KEYPAD_Init();
}

int main(void) {
	setup();

	while (1) {
		// Read raw signal from keypad
		uint8_t key_signal = KEYPAD_GetKey();

		_delay_ms(300);

		// Check for valid key press
		if (key_signal != 0xFF) { // Assuming 0xFF means no key pressed
			char key_str[4];

			// Check if it's a numeric key (1 to 9) or special key (A, B, C, D, *, #)
			if (key_signal >= '1' && key_signal <= '9') {
				// Convert key to numeric value
				uint8_t key_value = key_signal - '0'; // Convert ASCII value to numeric value
				itoa(key_value, key_str, 10); // Convert numeric value to string

				} else {
				// For special keys, just display the character
				key_str[0] = key_signal;
				key_str[1] = '\0'; // Null terminate the string
			}

			// Display the key on the LCD
			lcd_clrscr();
			lcd_puts("Key Pressed:");
			lcd_gotoxy(0, 1);
			lcd_puts(key_str);
		}
	}


	return 0;
}
